package work1;


public class Word {

	private String english;
	private String japanese;

	public Word(String eng, String jp){

		this.english = eng;
		this.japanese = jp;

	}

	public void toString(String word){

	}

	public String getEnglish() {
		return this.english;
	}

	public void setEnglish(String english) {
		this.english = english;
	}

	public String getJapanese() {
		return this.japanese;
	}

	public void setJapanese(String japanese) {
		this.japanese = japanese;
	}

	public void inWord(String input) {

	}

}
