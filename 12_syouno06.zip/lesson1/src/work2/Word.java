package work2;


public class Word{

	private String english;
	private String japanese;

	public Word(){

	}

	public void toString(String word){

	}

	public String getEnglish() {
		return this.english;
	}

	public void setEnglish(String english) {
		this.english = english;
	}

	public String getJapanese() {
		return this.japanese;
	}

	public void setJapanese(String japanese) {
		this.japanese = japanese;
	}

	public void inWord(String input) {
		System.out.println("入力確認。");

		String[] tmp = new String[2];
		if(input.contains(" ")) {
			tmp = input.split(" ");
		}else if(input.contains("　")) {
			tmp = input.split("　");
		}

		this.english = tmp[0];
		this.japanese = tmp[1];
	}

	@Override
	public String toString() {
		return "英単語:" + this.english + "　日本語:" + this.japanese;
	}



}
