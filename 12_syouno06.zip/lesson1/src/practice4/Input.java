package practice4;

import java.util.Scanner;

public class Input {

	public static void main(String[] args){
		String[] words = new String[3];

		System.out.println("単語を入力してください\"e\"で終了します。");
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		int index = 0;
		try{
			while(!input.equals("e")){
				words[index] = input;
				index++;
				System.out.println("次の単語を入力してください\"e\"で終了します。");
				input = sc.nextLine();
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("用意した容量をオーバーしました。");
		}

		System.out.println("プログラムを終了します");
		sc.close();
	}

}
