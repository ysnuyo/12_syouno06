package practice2;

import practice1.Human;

public class Programmer extends Human{
	public String type;

	public Programmer(){
		super();
		this.type = "プログラマー";
	}

	public Programmer(String name, String sex, int age, int tall, int weight){
		super(name,sex,age,tall,weight);
		System.out.println("子クラスのコンストラクタを実行");
		this.type = "プログラマー";
	}

	@Override
	public void printProf(){
		System.out.println("私は\n"+ this.getName() + "\n" + this.getSex() + " " + this.getAge() + "歳\n" + this.getTall() + "cm\n" + this.getWeight() + "kg\n" + "職種は" + this.type+"\n"+ "です。\n");
	}

}

