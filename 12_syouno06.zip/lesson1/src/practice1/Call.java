package practice1;

import practice2.Consultant;
import practice2.Programmer;

public class Call{
	public static void main(String[] args){

		//インスタンス1を生成
		//Human hito1 = new Human("山田 太郎","男",23,175,60);
		Programmer hito1 = new Programmer("山田 太郎","男",23,175,60);

		//インスタンス2を生成
		Consultant hito2 = new Consultant("鈴木 花子","女",25,160,45);

		//メソッドの呼び出し インスタンス1の情報が表示される
		hito1.printProf();


		//メソッドの呼び出し インスタンス2の情報が表示される
		hito2.printProf();

		//クラスフィールドを呼び出す
		//Human.nickname = "ヤマ";
		//クラスメソッドを呼び出す
		//Human.printTest();
	}
}