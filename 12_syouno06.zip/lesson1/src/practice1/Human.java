package practice1;

public class Human{
	private String name;  //氏名
	private String sex;   //性別
	private int age;      //年齢
	private int tall;     //身長
	private int weight;   //体重

	//staticな変数の宣言
	public static String nickname;//クラスフィールド

	//staticなメソッドの宣言
	public static void printTest(){//メソッドフィールド
		System.out.println(nickname);
	}


	public String getName(){
		return this.name;
	}
	public void setName(String name){
		this.name = name;
	}


	public String getSex(){
		return this.sex;
	}
	public void setSex(String sex){
		this.sex = sex;
	}


	public int getAge(){
		return this.age;
	}
	public void setAge(int age){
		this.age = age;
	}


	public int getTall(){
		return this.tall;
	}
	public void setTall(int tall){
		this.tall = tall;
	}


	public int getWeight(){
		return this.weight;
	}
	public void setWeight(int weight){
		this.weight = weight;
	}



	public Human(){

	}


	public Human(String name, String sex, int age, int tall, int weight){
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.tall = tall;
		this.weight = weight;
	}


	public void printProf(){
		System.out.println(	"私は\n"+ this.name + "\n" + this.sex + " " + this.age + "歳\n" + this.tall + "cm\n" + this.weight + "kg\n" + "です"	);
	}


}